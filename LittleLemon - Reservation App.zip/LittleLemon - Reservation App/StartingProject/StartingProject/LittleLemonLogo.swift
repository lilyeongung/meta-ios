import SwiftUI

struct LittleLemonLogo: View {
    var body: some View {
        
        // MARK: - Task 1: Creating a view for the logo -> 2.LocationsView
        Image("littleLemon")
    }
}

struct LittleLemonLogo_Previews: PreviewProvider {
    static var previews: some View {
        LittleLemonLogo()
    }
}


