//
//  MenuItemsOptionView.swift
//  LittleLemonDinnerMenu
//
//  Created by Andrew Park on 6/12/24.
//

import SwiftUI

struct MenuItemsOptionView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var viewModel: MenuViewViewModel
    
    var body: some View {
        NavigationView {
            List {
                
                // MARK: implement filtering -> toggle?
                Section("Selected Categories") {
                    ForEach(MenuCategory.allCases, id: \.self) { category in
                        // when i loop through the enum, create a toggle for each category (food, drink, dessert)
                        // how can I check a diff condition for each category?
                        if category.rawValue == "Food" {
                            Toggle(category.rawValue, isOn: $viewModel.isCategoryFood)
                        }
                        if category.rawValue == "Drink" {
                            Toggle(category.rawValue, isOn: $viewModel.isCategoryDrink)

                        }
                        if category.rawValue == "Dessert" {
                            Toggle(category.rawValue, isOn: $viewModel.isCategoryDessert)

                        }
                        
//                        switch category {
//                        case .food: Toggle(category.rawValue, isOn: $viewModel.isCategoryFood)
//                        case .drink: Toggle(category.rawValue, isOn: $viewModel.isCategoryDrink)
//                        case .dessert: Toggle(category.rawValue, isOn: $viewModel.isCategoryDessert)
//                        }
                        
                    }
                }
                // MARK: implement sorting -> picker
                Section("Sort By") {
                    ForEach(SortBy.allCases, id: \.self) { sortOption in
                        Text(sortOption.rawValue)
                    }
                }
            }
//            .listStyle(.plain)
            .navigationTitle("Filter")
            .navigationBarItems(trailing: Button("Done") {
                // dismiss how???
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
}


#Preview {
    MenuItemsOptionView().environmentObject(MenuViewViewModel())
}
